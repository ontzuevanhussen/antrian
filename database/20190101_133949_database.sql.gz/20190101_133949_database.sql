-- ---------------------------------------------------------
--
-- SIMPLE SQL Dump
-- 
-- nawa (at) yahoo (dot) com
--
-- Host Connection Info: localhost via TCP/IP
-- Generation Time: January 01, 2019 at 13:39 PM ( ASIA/JAKARTA )
-- PHP Version: 7.1.1
--
-- ---------------------------------------------------------



SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;


-- ---------------------------------------------------------
--
-- Table structure for table : `pelanggan`
--
-- ---------------------------------------------------------

CREATE TABLE `pelanggan` (
  `id_pelanggan` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(30) NOT NULL,
  `no_hp` varchar(13) NOT NULL,
  `created_user` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_user` int(11) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id_pelanggan`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `pelanggan`
--

INSERT INTO `pelanggan` (`id_pelanggan`, `nama`, `no_hp`, `created_user`, `created_date`, `updated_user`, `updated_date`) VALUES
(1, 'Danang', 081377783334, 2, '2019-01-01 13:27:37', '', ''),
(2, 'Indra', 082186869898, 2, '2019-01-01 13:27:48', '', ''),
(3, 'Dina', 085780892906, 2, '2019-01-01 13:27:59', '', ''),
(4, 'Hana', 085669919769, 2, '2019-01-01 13:28:12', '', ''),
(5, 'Teguh', 081365657894, 2, '2019-01-01 13:28:26', '', ''),
(6, 'Darma', 082385864123, 2, '2019-01-01 13:28:38', '', ''),
(7, 'Agung', 081299784522, 2, '2019-01-01 13:28:53', '', ''),
(8, 'Feri', 083165894532, 2, '2019-01-01 13:29:13', '', ''),
(9, 'Fajar', 089599751234, 2, '2019-01-01 13:29:25', '', ''),
(10, 'Dedi', 085786875533, 2, '2019-01-01 13:29:37', '', ''),
(11, 'Wuri', 088896887712, 2, '2019-01-01 13:29:48', '', '');



-- ---------------------------------------------------------
--
-- Table structure for table : `penjualan`
--
-- ---------------------------------------------------------

CREATE TABLE `penjualan` (
  `id_penjualan` int(11) NOT NULL AUTO_INCREMENT,
  `tanggal` date NOT NULL,
  `pelanggan` int(11) NOT NULL,
  `pulsa` int(11) NOT NULL,
  `jumlah_bayar` int(11) NOT NULL,
  `created_user` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_user` int(11) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id_penjualan`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `penjualan`
--

INSERT INTO `penjualan` (`id_penjualan`, `tanggal`, `pelanggan`, `pulsa`, `jumlah_bayar`, `created_user`, `created_date`, `updated_user`, `updated_date`) VALUES
(1, '2019-01-01', 1, 1, 27000, 2, '2019-01-01 13:30:13', '', ''),
(2, '2019-01-01', 3, 6, 12000, 2, '2019-01-01 13:30:31', '', ''),
(3, '2019-01-01', 2, 3, 52000, 2, '2019-01-01 13:30:50', '', ''),
(4, '2019-01-01', 9, 13, 12000, 2, '2019-01-01 13:32:37', '', ''),
(5, '2019-01-01', 7, 1, 27000, 2, '2019-01-01 13:33:04', '', ''),
(6, '2019-01-01', 11, 40, 102000, 2, '2019-01-01 13:36:26', '', ''),
(7, '2019-01-01', 10, 7, 22000, 2, '2019-01-01 13:37:14', '', '');



-- ---------------------------------------------------------
--
-- Table structure for table : `pulsa`
--
-- ---------------------------------------------------------

CREATE TABLE `pulsa` (
  `id_pulsa` int(11) NOT NULL AUTO_INCREMENT,
  `provider` varchar(15) NOT NULL,
  `nominal` int(11) NOT NULL,
  `harga` int(11) NOT NULL,
  `created_user` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_user` int(11) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id_pulsa`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

--
-- Dumping data for table `pulsa`
--

INSERT INTO `pulsa` (`id_pulsa`, `provider`, `nominal`, `harga`, `created_user`, `created_date`, `updated_user`, `updated_date`) VALUES
(1, 'Telkomsel', 25000, 27000, 1, '2019-01-01 00:00:00', '', ''),
(2, 'Telkomsel', 40000, 42000, 1, '2019-01-01 00:00:00', '', ''),
(3, 'Telkomsel', 50000, 52000, 1, '2019-01-01 00:00:00', '', ''),
(4, 'Telkomsel', 100000, 102000, 1, '2019-01-01 00:00:00', '', ''),
(5, 'Indosat Ooredoo', 5000, 7000, 1, '2019-01-01 00:00:00', '', ''),
(6, 'Indosat Ooredoo', 10000, 12000, 1, '2019-01-01 00:00:00', '', ''),
(7, 'Indosat Ooredoo', 20000, 22000, 1, '2019-01-01 00:00:00', '', ''),
(8, 'Indosat Ooredoo', 25000, 27000, 1, '2019-01-01 00:00:00', '', ''),
(9, 'Indosat Ooredoo', 30000, 32000, 1, '2019-01-01 00:00:00', '', ''),
(10, 'Indosat Ooredoo', 50000, 52000, 1, '2019-01-01 00:00:00', '', ''),
(11, 'Indosat Ooredoo', 100000, 102000, 1, '2019-01-01 00:00:00', '', ''),
(12, 'Tri Indonesia', 5000, 7000, 1, '2019-01-01 00:00:00', '', ''),
(13, 'Tri Indonesia', 10000, 12000, 1, '2019-01-01 00:00:00', '', ''),
(14, 'Tri Indonesia', 15000, 17000, 1, '2019-01-01 00:00:00', '', ''),
(15, 'Tri Indonesia', 20000, 22000, 1, '2019-01-01 00:00:00', '', ''),
(16, 'Tri Indonesia', 25000, 27000, 1, '2019-01-01 00:00:00', '', ''),
(17, 'Tri Indonesia', 30000, 32000, 1, '2019-01-01 00:00:00', '', ''),
(18, 'Tri Indonesia', 50000, 52000, 1, '2019-01-01 00:00:00', '', ''),
(19, 'Tri Indonesia', 100000, 102000, 1, '2019-01-01 00:00:00', '', ''),
(20, 'AXIS', 5000, 7000, 1, '2019-01-01 00:00:00', '', ''),
(21, 'AXIS', 10000, 12000, 1, '2019-01-01 00:00:00', '', ''),
(22, 'AXIS', 15000, 17000, 1, '2019-01-01 00:00:00', '', ''),
(23, 'AXIS', 25000, 27000, 1, '2019-01-01 00:00:00', '', ''),
(24, 'AXIS', 30000, 32000, 1, '2019-01-01 00:00:00', '', ''),
(25, 'AXIS', 50000, 52000, 1, '2019-01-01 00:00:00', '', ''),
(26, 'AXIS', 100000, 102000, 1, '2019-01-01 00:00:00', '', ''),
(27, 'XL Axiata', 5000, 7000, 1, '2019-01-01 00:00:00', '', ''),
(28, 'XL Axiata', 10000, 12000, 1, '2019-01-01 00:00:00', '', ''),
(29, 'XL Axiata', 15000, 17000, 1, '2019-01-01 00:00:00', '', ''),
(30, 'XL Axiata', 25000, 27000, 1, '2019-01-01 00:00:00', '', ''),
(31, 'XL Axiata', 30000, 32000, 1, '2019-01-01 00:00:00', '', ''),
(32, 'XL Axiata', 50000, 52000, 1, '2019-01-01 00:00:00', '', ''),
(33, 'XL Axiata', 100000, 102000, 1, '2019-01-01 00:00:00', '', ''),
(34, 'Smartfren', 5000, 7000, 1, '2019-01-01 00:00:00', '', ''),
(35, 'Smartfren', 10000, 12000, 1, '2019-01-01 00:00:00', '', ''),
(36, 'Smartfren', 20000, 22000, 1, '2019-01-01 00:00:00', '', ''),
(37, 'Smartfren', 25000, 27000, 1, '2019-01-01 00:00:00', '', ''),
(38, 'Smartfren', 50000, 52000, 1, '2019-01-01 00:00:00', '', ''),
(39, 'Smartfren', 60000, 62000, 1, '2019-01-01 00:00:00', '', ''),
(40, 'Smartfren', 100000, 102000, 1, '2019-01-01 00:00:00', '', '');



-- ---------------------------------------------------------
--
-- Table structure for table : `sys_audit_trail`
--
-- ---------------------------------------------------------

CREATE TABLE `sys_audit_trail` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tanggal` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `username` varchar(30) NOT NULL,
  `aksi` enum('Insert','Update','Delete') NOT NULL,
  `keterangan` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sys_audit_trail`
--

INSERT INTO `sys_audit_trail` (`id`, `tanggal`, `username`, `aksi`, `keterangan`) VALUES
(1, '2019-01-01 13:24:44', 1, 'Insert', '<b>Insert</b> data pengguna pada tabel <b>sys_users</b>.<br><b>[ID User : </b>1<b>][Nama User : </b>Indra Styawantoro<b>][Username : </b>indrasatya<b>][Password : </b>2437018d9a925c9fce796b99bfb9591728c5f208<b>][Hak Akses : </b>Administrator<b>][Blokir : </b>Tidak<b>]</b>'),
(2, '2019-01-01 13:24:59', 1, 'Insert', '<b>Insert</b> data pengguna pada tabel <b>sys_users</b>.<br><b>[ID User : </b>2<b>][Nama User : </b>Danang Kesuma<b>][Username : </b>danang<b>][Password : </b>f8966cc671220b4858818afca4a8c9eedbeb6a5d<b>][Hak Akses : </b>Operator<b>][Blokir : </b>Tidak<b>]</b>'),
(3, '2019-01-01 13:26:05', 1, 'Update', '<b>Update</b> data konfigurasi aplikasi pada tabel <b>sys_config</b>.<br><b>Data Lama = [Nama Konter : </b><b>][Alamat : </b><b>][Telepon : </b><b>][Email : </b><b>][Website : </b><b>][Logo : </b><b>],<br> Data Baru = [Nama Konter : </b>NUSANTARA CELL<b>][Alamat : </b>Rajabasa, Bandar Lampung, Lampung<b>][Telepon : </b>081377783334<b>][Email : </b>nusantaracell@gmail.com<b>][Website : </b>www.nusantaracell.com<b>][Logo : </b>logo.png<b>]</b>'),
(4, '2019-01-01 13:26:27', 1, 'Insert', '<b>Insert</b> data pulsa pada tabel <b>pulsa</b>.<br><b>[ID Pulsa : </b>1<b>][Provider : </b>Telkomsel<b>][Nominal : </b>25000<b>][Harga : </b>27000<b>]</b>'),
(5, '2019-01-01 13:26:27', 1, 'Insert', '<b>Insert</b> data pulsa pada tabel <b>pulsa</b>.<br><b>[ID Pulsa : </b>2<b>][Provider : </b>Telkomsel<b>][Nominal : </b>40000<b>][Harga : </b>42000<b>]</b>'),
(6, '2019-01-01 13:26:27', 1, 'Insert', '<b>Insert</b> data pulsa pada tabel <b>pulsa</b>.<br><b>[ID Pulsa : </b>3<b>][Provider : </b>Telkomsel<b>][Nominal : </b>50000<b>][Harga : </b>52000<b>]</b>'),
(7, '2019-01-01 13:26:27', 1, 'Insert', '<b>Insert</b> data pulsa pada tabel <b>pulsa</b>.<br><b>[ID Pulsa : </b>4<b>][Provider : </b>Telkomsel<b>][Nominal : </b>100000<b>][Harga : </b>102000<b>]</b>'),
(8, '2019-01-01 13:26:27', 1, 'Insert', '<b>Insert</b> data pulsa pada tabel <b>pulsa</b>.<br><b>[ID Pulsa : </b>5<b>][Provider : </b>Indosat Ooredoo<b>][Nominal : </b>5000<b>][Harga : </b>7000<b>]</b>'),
(9, '2019-01-01 13:26:27', 1, 'Insert', '<b>Insert</b> data pulsa pada tabel <b>pulsa</b>.<br><b>[ID Pulsa : </b>6<b>][Provider : </b>Indosat Ooredoo<b>][Nominal : </b>10000<b>][Harga : </b>12000<b>]</b>'),
(10, '2019-01-01 13:26:27', 1, 'Insert', '<b>Insert</b> data pulsa pada tabel <b>pulsa</b>.<br><b>[ID Pulsa : </b>7<b>][Provider : </b>Indosat Ooredoo<b>][Nominal : </b>20000<b>][Harga : </b>22000<b>]</b>'),
(11, '2019-01-01 13:26:27', 1, 'Insert', '<b>Insert</b> data pulsa pada tabel <b>pulsa</b>.<br><b>[ID Pulsa : </b>8<b>][Provider : </b>Indosat Ooredoo<b>][Nominal : </b>25000<b>][Harga : </b>27000<b>]</b>'),
(12, '2019-01-01 13:26:27', 1, 'Insert', '<b>Insert</b> data pulsa pada tabel <b>pulsa</b>.<br><b>[ID Pulsa : </b>9<b>][Provider : </b>Indosat Ooredoo<b>][Nominal : </b>30000<b>][Harga : </b>32000<b>]</b>'),
(13, '2019-01-01 13:26:27', 1, 'Insert', '<b>Insert</b> data pulsa pada tabel <b>pulsa</b>.<br><b>[ID Pulsa : </b>10<b>][Provider : </b>Indosat Ooredoo<b>][Nominal : </b>50000<b>][Harga : </b>52000<b>]</b>'),
(14, '2019-01-01 13:26:27', 1, 'Insert', '<b>Insert</b> data pulsa pada tabel <b>pulsa</b>.<br><b>[ID Pulsa : </b>11<b>][Provider : </b>Indosat Ooredoo<b>][Nominal : </b>100000<b>][Harga : </b>102000<b>]</b>'),
(15, '2019-01-01 13:26:27', 1, 'Insert', '<b>Insert</b> data pulsa pada tabel <b>pulsa</b>.<br><b>[ID Pulsa : </b>12<b>][Provider : </b>Tri Indonesia<b>][Nominal : </b>5000<b>][Harga : </b>7000<b>]</b>'),
(16, '2019-01-01 13:26:27', 1, 'Insert', '<b>Insert</b> data pulsa pada tabel <b>pulsa</b>.<br><b>[ID Pulsa : </b>13<b>][Provider : </b>Tri Indonesia<b>][Nominal : </b>10000<b>][Harga : </b>12000<b>]</b>'),
(17, '2019-01-01 13:26:27', 1, 'Insert', '<b>Insert</b> data pulsa pada tabel <b>pulsa</b>.<br><b>[ID Pulsa : </b>14<b>][Provider : </b>Tri Indonesia<b>][Nominal : </b>15000<b>][Harga : </b>17000<b>]</b>'),
(18, '2019-01-01 13:26:27', 1, 'Insert', '<b>Insert</b> data pulsa pada tabel <b>pulsa</b>.<br><b>[ID Pulsa : </b>15<b>][Provider : </b>Tri Indonesia<b>][Nominal : </b>20000<b>][Harga : </b>22000<b>]</b>'),
(19, '2019-01-01 13:26:27', 1, 'Insert', '<b>Insert</b> data pulsa pada tabel <b>pulsa</b>.<br><b>[ID Pulsa : </b>16<b>][Provider : </b>Tri Indonesia<b>][Nominal : </b>25000<b>][Harga : </b>27000<b>]</b>'),
(20, '2019-01-01 13:26:27', 1, 'Insert', '<b>Insert</b> data pulsa pada tabel <b>pulsa</b>.<br><b>[ID Pulsa : </b>17<b>][Provider : </b>Tri Indonesia<b>][Nominal : </b>30000<b>][Harga : </b>32000<b>]</b>'),
(21, '2019-01-01 13:26:27', 1, 'Insert', '<b>Insert</b> data pulsa pada tabel <b>pulsa</b>.<br><b>[ID Pulsa : </b>18<b>][Provider : </b>Tri Indonesia<b>][Nominal : </b>50000<b>][Harga : </b>52000<b>]</b>'),
(22, '2019-01-01 13:26:27', 1, 'Insert', '<b>Insert</b> data pulsa pada tabel <b>pulsa</b>.<br><b>[ID Pulsa : </b>19<b>][Provider : </b>Tri Indonesia<b>][Nominal : </b>100000<b>][Harga : </b>102000<b>]</b>'),
(23, '2019-01-01 13:26:27', 1, 'Insert', '<b>Insert</b> data pulsa pada tabel <b>pulsa</b>.<br><b>[ID Pulsa : </b>20<b>][Provider : </b>AXIS<b>][Nominal : </b>5000<b>][Harga : </b>7000<b>]</b>'),
(24, '2019-01-01 13:26:27', 1, 'Insert', '<b>Insert</b> data pulsa pada tabel <b>pulsa</b>.<br><b>[ID Pulsa : </b>21<b>][Provider : </b>AXIS<b>][Nominal : </b>10000<b>][Harga : </b>12000<b>]</b>'),
(25, '2019-01-01 13:26:27', 1, 'Insert', '<b>Insert</b> data pulsa pada tabel <b>pulsa</b>.<br><b>[ID Pulsa : </b>22<b>][Provider : </b>AXIS<b>][Nominal : </b>15000<b>][Harga : </b>17000<b>]</b>'),
(26, '2019-01-01 13:26:27', 1, 'Insert', '<b>Insert</b> data pulsa pada tabel <b>pulsa</b>.<br><b>[ID Pulsa : </b>23<b>][Provider : </b>AXIS<b>][Nominal : </b>25000<b>][Harga : </b>27000<b>]</b>'),
(27, '2019-01-01 13:26:27', 1, 'Insert', '<b>Insert</b> data pulsa pada tabel <b>pulsa</b>.<br><b>[ID Pulsa : </b>24<b>][Provider : </b>AXIS<b>][Nominal : </b>30000<b>][Harga : </b>32000<b>]</b>'),
(28, '2019-01-01 13:26:27', 1, 'Insert', '<b>Insert</b> data pulsa pada tabel <b>pulsa</b>.<br><b>[ID Pulsa : </b>25<b>][Provider : </b>AXIS<b>][Nominal : </b>50000<b>][Harga : </b>52000<b>]</b>'),
(29, '2019-01-01 13:26:27', 1, 'Insert', '<b>Insert</b> data pulsa pada tabel <b>pulsa</b>.<br><b>[ID Pulsa : </b>26<b>][Provider : </b>AXIS<b>][Nominal : </b>100000<b>][Harga : </b>102000<b>]</b>'),
(30, '2019-01-01 13:26:27', 1, 'Insert', '<b>Insert</b> data pulsa pada tabel <b>pulsa</b>.<br><b>[ID Pulsa : </b>27<b>][Provider : </b>XL Axiata<b>][Nominal : </b>5000<b>][Harga : </b>7000<b>]</b>'),
(31, '2019-01-01 13:26:27', 1, 'Insert', '<b>Insert</b> data pulsa pada tabel <b>pulsa</b>.<br><b>[ID Pulsa : </b>28<b>][Provider : </b>XL Axiata<b>][Nominal : </b>10000<b>][Harga : </b>12000<b>]</b>'),
(32, '2019-01-01 13:26:27', 1, 'Insert', '<b>Insert</b> data pulsa pada tabel <b>pulsa</b>.<br><b>[ID Pulsa : </b>29<b>][Provider : </b>XL Axiata<b>][Nominal : </b>15000<b>][Harga : </b>17000<b>]</b>'),
(33, '2019-01-01 13:26:27', 1, 'Insert', '<b>Insert</b> data pulsa pada tabel <b>pulsa</b>.<br><b>[ID Pulsa : </b>30<b>][Provider : </b>XL Axiata<b>][Nominal : </b>25000<b>][Harga : </b>27000<b>]</b>'),
(34, '2019-01-01 13:26:27', 1, 'Insert', '<b>Insert</b> data pulsa pada tabel <b>pulsa</b>.<br><b>[ID Pulsa : </b>31<b>][Provider : </b>XL Axiata<b>][Nominal : </b>30000<b>][Harga : </b>32000<b>]</b>'),
(35, '2019-01-01 13:26:27', 1, 'Insert', '<b>Insert</b> data pulsa pada tabel <b>pulsa</b>.<br><b>[ID Pulsa : </b>32<b>][Provider : </b>XL Axiata<b>][Nominal : </b>50000<b>][Harga : </b>52000<b>]</b>'),
(36, '2019-01-01 13:26:27', 1, 'Insert', '<b>Insert</b> data pulsa pada tabel <b>pulsa</b>.<br><b>[ID Pulsa : </b>33<b>][Provider : </b>XL Axiata<b>][Nominal : </b>100000<b>][Harga : </b>102000<b>]</b>'),
(37, '2019-01-01 13:26:27', 1, 'Insert', '<b>Insert</b> data pulsa pada tabel <b>pulsa</b>.<br><b>[ID Pulsa : </b>34<b>][Provider : </b>Smartfren<b>][Nominal : </b>5000<b>][Harga : </b>7000<b>]</b>'),
(38, '2019-01-01 13:26:27', 1, 'Insert', '<b>Insert</b> data pulsa pada tabel <b>pulsa</b>.<br><b>[ID Pulsa : </b>35<b>][Provider : </b>Smartfren<b>][Nominal : </b>10000<b>][Harga : </b>12000<b>]</b>'),
(39, '2019-01-01 13:26:27', 1, 'Insert', '<b>Insert</b> data pulsa pada tabel <b>pulsa</b>.<br><b>[ID Pulsa : </b>36<b>][Provider : </b>Smartfren<b>][Nominal : </b>20000<b>][Harga : </b>22000<b>]</b>'),
(40, '2019-01-01 13:26:27', 1, 'Insert', '<b>Insert</b> data pulsa pada tabel <b>pulsa</b>.<br><b>[ID Pulsa : </b>37<b>][Provider : </b>Smartfren<b>][Nominal : </b>25000<b>][Harga : </b>27000<b>]</b>'),
(41, '2019-01-01 13:26:27', 1, 'Insert', '<b>Insert</b> data pulsa pada tabel <b>pulsa</b>.<br><b>[ID Pulsa : </b>38<b>][Provider : </b>Smartfren<b>][Nominal : </b>50000<b>][Harga : </b>52000<b>]</b>'),
(42, '2019-01-01 13:26:27', 1, 'Insert', '<b>Insert</b> data pulsa pada tabel <b>pulsa</b>.<br><b>[ID Pulsa : </b>39<b>][Provider : </b>Smartfren<b>][Nominal : </b>60000<b>][Harga : </b>62000<b>]</b>'),
(43, '2019-01-01 13:26:27', 1, 'Insert', '<b>Insert</b> data pulsa pada tabel <b>pulsa</b>.<br><b>[ID Pulsa : </b>40<b>][Provider : </b>Smartfren<b>][Nominal : </b>100000<b>][Harga : </b>102000<b>]</b>'),
(44, '2019-01-01 13:27:37', 2, 'Insert', '<b>Insert</b> data pelanggan pada tabel <b>pelanggan</b>.<br><b>[ID Pelanggan : </b>1<b>][Nama Pelanggan : </b>Danang<b>][No. HP : </b>081377783334<b>]</b>'),
(45, '2019-01-01 13:27:48', 2, 'Insert', '<b>Insert</b> data pelanggan pada tabel <b>pelanggan</b>.<br><b>[ID Pelanggan : </b>2<b>][Nama Pelanggan : </b>Indra<b>][No. HP : </b>082186869898<b>]</b>'),
(46, '2019-01-01 13:27:59', 2, 'Insert', '<b>Insert</b> data pelanggan pada tabel <b>pelanggan</b>.<br><b>[ID Pelanggan : </b>3<b>][Nama Pelanggan : </b>Dina<b>][No. HP : </b>085780892906<b>]</b>'),
(47, '2019-01-01 13:28:12', 2, 'Insert', '<b>Insert</b> data pelanggan pada tabel <b>pelanggan</b>.<br><b>[ID Pelanggan : </b>4<b>][Nama Pelanggan : </b>Hana<b>][No. HP : </b>085669919769<b>]</b>'),
(48, '2019-01-01 13:28:26', 2, 'Insert', '<b>Insert</b> data pelanggan pada tabel <b>pelanggan</b>.<br><b>[ID Pelanggan : </b>5<b>][Nama Pelanggan : </b>Teguh<b>][No. HP : </b>081365657894<b>]</b>'),
(49, '2019-01-01 13:28:38', 2, 'Insert', '<b>Insert</b> data pelanggan pada tabel <b>pelanggan</b>.<br><b>[ID Pelanggan : </b>6<b>][Nama Pelanggan : </b>Darma<b>][No. HP : </b>082385864123<b>]</b>'),
(50, '2019-01-01 13:28:53', 2, 'Insert', '<b>Insert</b> data pelanggan pada tabel <b>pelanggan</b>.<br><b>[ID Pelanggan : </b>7<b>][Nama Pelanggan : </b>Agung<b>][No. HP : </b>081299784522<b>]</b>'),
(51, '2019-01-01 13:29:13', 2, 'Insert', '<b>Insert</b> data pelanggan pada tabel <b>pelanggan</b>.<br><b>[ID Pelanggan : </b>8<b>][Nama Pelanggan : </b>Feri<b>][No. HP : </b>083165894532<b>]</b>'),
(52, '2019-01-01 13:29:25', 2, 'Insert', '<b>Insert</b> data pelanggan pada tabel <b>pelanggan</b>.<br><b>[ID Pelanggan : </b>9<b>][Nama Pelanggan : </b>Fajar<b>][No. HP : </b>089599751234<b>]</b>'),
(53, '2019-01-01 13:29:37', 2, 'Insert', '<b>Insert</b> data pelanggan pada tabel <b>pelanggan</b>.<br><b>[ID Pelanggan : </b>10<b>][Nama Pelanggan : </b>Dedi<b>][No. HP : </b>085786875533<b>]</b>'),
(54, '2019-01-01 13:29:48', 2, 'Insert', '<b>Insert</b> data pelanggan pada tabel <b>pelanggan</b>.<br><b>[ID Pelanggan : </b>11<b>][Nama Pelanggan : </b>Wuri<b>][No. HP : </b>088896887712<b>]</b>'),
(55, '2019-01-01 13:30:13', 2, 'Insert', '<b>Insert</b> data penjualan pada tabel <b>penjualan</b>.<br><b>[ID Penjualan : </b>1<b>][Tanggal : </b>2019-01-01<b>][ID Pelanggan : </b>1<b>][ID Pulsa : </b>1<b>][Jumlah Bayar : </b>27000<b>]</b>'),
(56, '2019-01-01 13:30:31', 2, 'Insert', '<b>Insert</b> data penjualan pada tabel <b>penjualan</b>.<br><b>[ID Penjualan : </b>2<b>][Tanggal : </b>2019-01-01<b>][ID Pelanggan : </b>3<b>][ID Pulsa : </b>6<b>][Jumlah Bayar : </b>12000<b>]</b>'),
(57, '2019-01-01 13:30:50', 2, 'Insert', '<b>Insert</b> data penjualan pada tabel <b>penjualan</b>.<br><b>[ID Penjualan : </b>3<b>][Tanggal : </b>2019-01-01<b>][ID Pelanggan : </b>2<b>][ID Pulsa : </b>3<b>][Jumlah Bayar : </b>52000<b>]</b>'),
(58, '2019-01-01 13:32:37', 2, 'Insert', '<b>Insert</b> data penjualan pada tabel <b>penjualan</b>.<br><b>[ID Penjualan : </b>4<b>][Tanggal : </b>2019-01-01<b>][ID Pelanggan : </b>9<b>][ID Pulsa : </b>13<b>][Jumlah Bayar : </b>12000<b>]</b>'),
(59, '2019-01-01 13:33:04', 2, 'Insert', '<b>Insert</b> data penjualan pada tabel <b>penjualan</b>.<br><b>[ID Penjualan : </b>5<b>][Tanggal : </b>2019-01-01<b>][ID Pelanggan : </b>7<b>][ID Pulsa : </b>1<b>][Jumlah Bayar : </b>27000<b>]</b>'),
(60, '2019-01-01 13:36:26', 2, 'Insert', '<b>Insert</b> data penjualan pada tabel <b>penjualan</b>.<br><b>[ID Penjualan : </b>6<b>][Tanggal : </b>2019-01-01<b>][ID Pelanggan : </b>11<b>][ID Pulsa : </b>40<b>][Jumlah Bayar : </b>102000<b>]</b>'),
(61, '2019-01-01 13:37:14', 2, 'Insert', '<b>Insert</b> data penjualan pada tabel <b>penjualan</b>.<br><b>[ID Penjualan : </b>7<b>][Tanggal : </b>2019-01-01<b>][ID Pelanggan : </b>10<b>][ID Pulsa : </b>7<b>][Jumlah Bayar : </b>22000<b>]</b>');



-- ---------------------------------------------------------
--
-- Table structure for table : `sys_config`
--
-- ---------------------------------------------------------

CREATE TABLE `sys_config` (
  `id` tinyint(1) NOT NULL AUTO_INCREMENT,
  `nama_konter` varchar(30) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `telepon` varchar(13) NOT NULL,
  `email` varchar(30) NOT NULL,
  `website` varchar(30) NOT NULL,
  `logo` varchar(30) NOT NULL,
  `updated_user` int(11) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sys_config`
--

INSERT INTO `sys_config` (`id`, `nama_konter`, `alamat`, `telepon`, `email`, `website`, `logo`, `updated_user`, `updated_date`) VALUES
(1, 'NUSANTARA CELL', 'Rajabasa, Bandar Lampung, Lampung', 081377783334, 'nusantaracell@gmail.com', 'www.nusantaracell.com', 'logo.png', 1, '2019-01-01 13:26:05');



-- ---------------------------------------------------------
--
-- Table structure for table : `sys_database`
--
-- ---------------------------------------------------------

CREATE TABLE `sys_database` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_file` varchar(50) NOT NULL,
  `ukuran_file` varchar(10) NOT NULL,
  `created_user` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



-- ---------------------------------------------------------
--
-- Table structure for table : `sys_users`
--
-- ---------------------------------------------------------

CREATE TABLE `sys_users` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `nama_user` varchar(30) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(45) NOT NULL,
  `hak_akses` enum('Administrator','Operator') NOT NULL,
  `blokir` enum('Ya','Tidak') NOT NULL,
  `created_user` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_user` int(11) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sys_users`
--

INSERT INTO `sys_users` (`id_user`, `nama_user`, `username`, `password`, `hak_akses`, `blokir`, `created_user`, `created_date`, `updated_user`, `updated_date`) VALUES
(1, 'Indra Styawantoro', 'indrasatya', '2437018d9a925c9fce796b99bfb9591728c5f208', 'Administrator', 'Tidak', 1, '2019-01-01 13:24:44', '', ''),
(2, 'Danang Kesuma', 'danang', 'f8966cc671220b4858818afca4a8c9eedbeb6a5d', 'Operator', 'Tidak', 1, '2019-01-01 13:24:59', '', '');


/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;